# Shared instruction string for multiprocessing
instruction = ''
glove_connected = False
drone_connected = False

def write_instr(instr: str):
    '''Write instruction to shared variable'''
    global instruction
    instruction = instr

def set_glove_on():
    global glove_connected
    glove_connected = True

def set_glove_off():
    global glove_connected
    glove_connected = False

def set_drone_on():
    global drone_connected
    drone_connected = True

def set_drone_off():
    global drone_connected
    drone_connected = False